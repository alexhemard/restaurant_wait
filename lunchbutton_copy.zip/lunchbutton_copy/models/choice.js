
var mongoose = exports.mongoose = require('mongoose')
  , Schema = mongoose.Schema
  , UserSchema = require('./user')
;

exports = module.exports = new Schema({

  user: { type: Schema.ObjectId, ref: 'User' },
  vote: { type: Number, default: 0 }

});
