
var mongoose = exports.mongoose = require('mongoose')
  , Schema = mongoose.Schema
  , PlaceSchema = require('./place')
  , Place = mongoose.model('Place', PlaceSchema)
  , CommentSchema = require('./comment')
  , Comment = mongoose.model('Comment', CommentSchema)
  , _ = require('underscore')
;

exports = module.exports = new Schema({

  lat: { type: Number, required: true },
  lon: { type: Number, required: true },
  places: [PlaceSchema],
  comments: [CommentSchema],
  userVotesMap: { type: {}, default: {} },
  placeVotesMap: { type: {}, default: {} }

});

exports.virtual('googlePlaces').set(function(googlePlaces) {
  var places = [];
  for(var i = 0; i < Math.min(googlePlaces.length, 60); i++) {
    var place = new Place();
    place.setGoogle(googlePlaces[i]);
    places.push(place);
  }
  this.places = places;
});

exports.method('doVote', function(user, placeId, vote) {
  var place = this.places.id(placeId);
  
  if(!this.userVotesMap[user._id]) {
    this.userVotesMap[user._id] = {};
    this.markModified('userVotesMap.' + user._id);
  }
  this.userVotesMap[user._id][placeId] = vote;
  this.markModified('userVotesMap.' + user._id + '.' + placeId);
  
  if(!this.placeVotesMap[placeId]) {
    this.placeVotesMap[placeId] = {};
    this.markModified('placeVotesMap.' + placeId);
  }
  this.placeVotesMap[placeId][user._id] = vote;
  this.markModified('placeVotesMap.' + placeId + '.' + user._id);

  place.setScore(this.placeVotesMap[placeId]);
});

exports.method('doComment', function(user, text) {
  this.comments.push(new Comment({ username: user.name, text: text }));
});

exports.method('sortPlaces', function() {
  this.places = _.sortBy(this.places, function(x) { return x.score * -1; });
  return this;
});
