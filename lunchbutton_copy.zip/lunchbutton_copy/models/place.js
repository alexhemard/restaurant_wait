
var mongoose = exports.mongoose = require('mongoose')
  , Schema = mongoose.Schema
  , UserSchema = require('./user')
;

exports = module.exports = new Schema({

  score: { type: Number, default: 0 },
  google: {}

});

exports.method('setGoogle', function(googlePlace) {
  this.google = googlePlace;
  for(var i in this.google) this.markModified('google.'+i);
});

exports.method('setScore', function(votesMap) {
  var score = 0;
  for(var userId in votesMap) {
    var voteVal = votesMap[userId];
    if(voteVal > 0) score++;
    if(voteVal < 0) score--;
  }
  this.score = score;
});
