
var mongoose = exports.mongoose = require('mongoose')
  , Schema = mongoose.Schema
  , UserSchema = require('./user')
;

exports = module.exports = new Schema({

  username: { type: String },
  text: { type: String }

});
