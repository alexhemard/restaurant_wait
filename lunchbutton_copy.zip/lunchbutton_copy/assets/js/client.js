//= require jquery
//= require jquery.validate
//= require bootstrapManifest
//= require socket.io
//= require underscore
//= require backbone
//= require baseClasses
//= require_tree ./models

// bootstrap hack to stop dropdowns from disappearing on mobile
$('body').on('touchstart.dropdown', '.dropdown-menu', function (e) { e.stopPropagation(); });

(function(App) {

  _.extend(App, {

    init: function() {
      var _this = this;

      $(function() {
        _this.docReady();
      });

      $('#createLunch').on('submit', function(e) {
        e.preventDefault();
        if(navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(_this.locationSuccess, _this.locationError);
        }
        else this.locationError();
      });
    },

    docReady: function() {
      var _this = this;

      this.setupCurrentUser();

      $('#signInModal').on('shown', function() {
        $(this).find('input').first().focus().select();
      });

      $('#signOutButton').on('click', function(e) {
        e.preventDefault();
        _this.signOut();
      });

      $('.vote').on('click', function(e) {
        if(!_this.user.id) {
          $('#signInModal').modal('show');
          return;
        }
        $this = $(this);

        $this.closest('.place').find('.vote').removeClass('mine');
        $this.addClass('mine');

        var data = $this.data();

        _this.lunch.doVote(data.place, data.val);
      });

      $('#commentForm').on('submit', function(e) {
        e.preventDefault();

        if(!_this.user.id) {
          $('#signInModal').modal('show');
          return;
        }

        var $textInput = $(this).find('input[name="text"]');
        _this.lunch.doComment($textInput.val());
        $textInput.val('');
      });
    },

    setSignedIn: function() {
      $('#currentUser').text(this.user.get('name'));
      $('body').removeClass('noUser').addClass('hasUser');
    },

    setSignedOut: function() {
      this.user.clear();
      $('body').removeClass('hasUser').addClass('noUser');
    },

    setupCurrentUser: function() {
      var _this = this;

      this.user = new App.Models.Me();
      this.user.fetch({
        success: function(user) {
          _this[user.id ? 'setSignedIn' : 'setSignedOut']();
          $('body').removeClass('userNotFetched');
          if(_this.afterUserFetch) _this.afterUserFetch();
        }
      });
    },

    signInComplete: function() {
      this.setupCurrentUser();
      $('#signInModal').modal('hide');
    },

    signOut: function() {
      var _this = this;

      $.ajax({
        url: '/auth/signOut',
        success: function() {
          _this.setSignedOut();
        }
      });
    },

    locationSuccess: function(location) {
      this.placesService = new google.maps.places.PlacesService(document.getElementById('map'));
      this.places = [];
      var _this = this;
      var meters = parseFloat($('#createLunch input[name="radius"]').val()) * 1609.34;

      this.placesService.nearbySearch(
        {
          radius: meters,
          location: new google.maps.LatLng(location.coords.latitude, location.coords.longitude),
          types: ['restaurant']
        },
        function(results, status, pagination) {

          for(var i = 0; i < results.length; i++) _this.places.push(results[i]);

          if(pagination.hasNextPage) {
            setTimeout(function() { pagination.nextPage(); }, 2000);
          }
          else {
            var lunch = new App.Models.Lunch({
              lat: location.coords.latitude,
              lon: location.coords.longitude,
              places: _this.places
            });
            lunch.save(null, {
              success: function(lunch) {
                console.log(lunch.id);
                window.location = '/lunches/' + lunch.id;
              },
              error: function() {
                console.log('Could not save');
              }
            });
          }
        }
      );
    },

    locationError: function() {
      console.log('LOCATION ERROR');
    },

    lunchPage: function(lunchId) {
      this.afterUserFetch = function() {
        if(this.lunch) window.location.reload();
        this.lunch = new App.Models.Lunch({ _id:lunchId });
        this.lunch.listen(this.user);
        this.lunch.on('change', _.bind(this.votesChanged, this));
        this.lunch.comments.on('add', _.bind(this.commentAdded, this));
      };
    },

    votesChanged: function() {
      var userVotes = this.lunch.getUserVotes();
      for(var placeId in userVotes) {
        var voteVal = userVotes[placeId];
        $('#' + placeId + ' .controls .vote[data-val="' + voteVal + '"]').addClass('mine');
      }
      var placePercents = this.lunch.getPlaceVotePercentages();
      for(var placeId in placePercents) {
        var percents = placePercents[placeId];
        $('#' + placeId + ' .votesBar.yea').animate({ 'width': percents.yea+'%' }, 500);
        $('#' + placeId + ' .votesBar.nay').animate({ 'width': percents.nay+'%' }, 500);
      }
    },

    commentAdded: function(model) {
      console.log(model);
      $('<div class="comment"><span class="username">&lt;' +
        model.get('username') +
        '&gt;</span> <span class="text">' +
        model.get('text') + 
        '</span></div>'
      ).appendTo('#commentsList');
      var list = $('#commentsList')[0];
      list.scrollTop = list.scrollHeight;
    }

  });

  App.init();

})(window.App);
