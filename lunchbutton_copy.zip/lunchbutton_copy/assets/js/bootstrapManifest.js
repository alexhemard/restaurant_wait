// MANIFEST FOR BOOTSTRAP PLUGINS TO INCLUDE
//= require ./bootstrap/bootstrap-transition
//= require ./bootstrap/bootstrap-alert
//= require ./bootstrap/bootstrap-modal
//= require ./bootstrap/bootstrap-dropdown
//= require ./bootstrap/bootstrap-scrollspy
//= require ./bootstrap/bootstrap-tab
//= require ./bootstrap/bootstrap-tooltip
//= require ./bootstrap/bootstrap-popover
//= require ./bootstrap/bootstrap-button
//= require ./bootstrap/bootstrap-collapse
//= require ./bootstrap/bootstrap-carousel
//= require ./bootstrap/bootstrap-typeahead
//= require ./bootstrap/bootstrap-affix
