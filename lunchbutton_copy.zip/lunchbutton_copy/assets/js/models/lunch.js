
(function(App) {

  App.Models.Vote = App.Models.Base.extend({

  });
  App.Collections.Vote = App.Collections.Base.extend({
    model: App.Models.Vote
  });

  App.Models.Place = App.Models.Base.extend({

  });
  App.Collections.Place = App.Collections.Base.extend({
    model: App.Models.Place
  });

  App.Models.Comment = App.Models.Base.extend({

  });
  App.Collections.Comment = App.Collections.Base.extend({
    model: App.Models.Comment
  });

  App.Models.Lunch = App.Models.Base.extend({

    resource: 'lunches',

    initialize: function() {
      this.subcollection('votes', 'Vote', 'lunch');
      this.subcollection('places', 'Place', 'lunch');
      this.subcollection('comments', 'Comment', 'lunch');
    },

    listen: function(user) {
      this.user = user;
      this.socket = io.connect();
      this.socket.on('update', _.bind(this.onSocketUpdate, this));
      this.socket.emit('join', this.id);
    },

    onSocketUpdate: function(data) {
      this.set(data);
    },

    doVote: function(placeId, vote) {
      if(this.user) this.socket.emit('vote', {
        lunch: this.id,
        place: placeId,
        vote: vote
      });
    },

    doComment: function(text) {
      if(this.user) this.socket.emit('comment', {
        lunch: this.id,
        text: text
      });
    },

    getUserVotes: function() {
      if(!this.user) return {};
      var map = this.get('userVotesMap');
      if(map) return map[this.user.id];
      return {};
    },

    getNumVoters: function() {
      var map = this.get('userVotesMap');
      var count = 0;
      for(var i in map) count++;
      return count;
    },

    getPlaceVoteCounts: function() {
      var counts = {};
      var map = this.get('placeVotesMap');
      for(var placeId in map) {
        counts[placeId] = { yea: 0, nay: 0 };

        var userVotes = map[placeId];
        for(var userId in userVotes) {
          var voteVal = userVotes[userId];

          if(voteVal > 0) counts[placeId].yea++;
          if(voteVal < 0) counts[placeId].nay++;
        }
      }
      return counts;
    },

    getPlaceVotePercentages: function() {
      var numVoters = this.getNumVoters();
      var counts = this.getPlaceVoteCounts();
      for(var i in counts) {
        counts[i].yea = counts[i].yea ? (counts[i].yea / numVoters)*100 : 0;
        counts[i].nay = counts[i].nay ? (counts[i].nay / numVoters)*100 : 0;
      }
      return counts;
    }

  });

})(window.App);
