exports.loggerFormat = 'dev';
exports.useErrorHandler = true;
exports.enableEmailLogin = true;
exports.mongodb = 'mongodb://nodejitsu_jwietelmann:vhqd5m5nhdicenj48a8akcos9k@ds039267.mongolab.com:39267/nodejitsu_jwietelmann_nodejitsudb9229123082';
exports.sessionSecret = 'ASGLHSDAfdsahfjsfhe;agwe$@TQGAWRv';
exports.twitter = {
  consumerKey: 'my consumer key',
  consumerSecret: 'my consumer secret'
};
exports.facebook = {
  clientID: 'my client id',
  clientSecret: 'my client secret',
  callbackURL: 'http://127.0.0.1:3000/auth/facebook/callback'
};
