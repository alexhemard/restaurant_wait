exports.show = function(req, res) {
  res.json({ TODO: 'Not yet implemented' });
};
