exports.show = function(req, res) {
  res.json(req.user);
};
