var models = require('../../models')
  , Lunch = models.Lunch
;

exports.create = function(req, res) {
  var lunch = new Lunch();
  lunch.googlePlaces = req.body.places;
  lunch.lat = req.body.lat;
  lunch.lon = req.body.lon;
  lunch.save(function(err, lunch) {
    if(err) throw err;
    res.json(lunch);
  });
};
