var models = require('../../models')
  , Lunch = models.Lunch
;

exports.index = function(req, res) {
  Lunch.find().exec(function(err, lunches) {
    if(err) return res.send(500);
    res.render('lunches/index', { title: 'Lunches', lunches: lunches })
  });
};

exports.show = function(req, res) {
  Lunch.findById(req.params.id, function(err, lunch) {
    if(err) return res.send(500);
    res.render('lunches/show', { title: '', lunch: lunch.sortPlaces() });
  });
};
