
exports.show = function(req, res) {
  res.render('users/show');
};
