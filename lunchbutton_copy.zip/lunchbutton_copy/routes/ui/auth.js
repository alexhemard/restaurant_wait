var passport = require('passport')
  , User = require("../../models").User
;

exports.email = passport.authenticate('email', {
  successRedirect: '/auth/finish',
  failureRedirect: '/auth/fail',
  failureFlash: true 
});

exports.register = function(req, res) {
  User.registerEmail(req.body.name, req.body.email, req.body.password, req.body.passwordConfirm,
    function(err, user) {
      if(err) return res.send(500);
      exports.email(req, res);
    }
  );
};

exports.guest = passport.authenticate('guest', {
  successRedirect: '/auth/finish',
  failureRedirect: '/auth/fail'
});

exports.twitter = passport.authenticate('twitter');
exports.twitterCallback = passport.authenticate('twitter', {
  successRedirect: '/auth/finish',
  failureRedirect: '/auth/fail',
  failureFlash: true
});

exports.facebook = passport.authenticate('facebook');
exports.facebookCallback = passport.authenticate('facebook', {
  successRedirect: '/auth/finish',
  failureRedirect: '/auth/fail',
  failureFlash: true
});

exports.signOut = function(req, res) {
  req.logOut();
  res.send(200);
}

exports.finish = function(req, res) {
  res.send('<script type="text/javascript">window.opener.App.signInComplete(); window.close();</script>')
};

exports.fail = function(req, res) {
  res.send('<script type="text/javascript">window.opener.App.signInFailed(); window.close();</script>');
};
